
var AWS = require("aws-sdk");

AWS.config.update({
  region: "us-west-2",
});

let getScanReport = (docClient,params)=>{
    let datas = []
    return new Promise((resolve,rejects)=>{
        docClient.scan(params, function(err, data) {
            if (err) {
                console.error("Unable to query. Error:", JSON.stringify(err, null, 2));
                rejects(JSON.stringify(err, null, 2))
            } else {
                console.log("Query succeeded.");
                data.Items.forEach(function(item) {    
                    datas.push(item)
                    console.log("item:",item)
                });
                resolve(datas)
            }
        });  
    });


}

async function main(){

    let report;

    let docClient = new AWS.DynamoDB.DocumentClient();

    console.log("Querying for movies from 1985.");

    let params = {
        TableName : "SalesReport",
        IndexName : "Product-Cup-index",

    };
    report = await getScanReport(docClient,params)
    console.log("report:",report)
    return report;
    
}
exports.handler = async (event) => {
    let reportData = await main();
    const response = {
            statusCode: 200,
            body:  reportData,
        };
    console.log("response:",response)
    return response
};                     